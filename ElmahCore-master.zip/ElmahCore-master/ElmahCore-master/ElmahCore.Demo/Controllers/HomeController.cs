﻿using System;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using ElmahCore.Demo.Models;

namespace ElmahCore.Demo.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var a = 5;
            var b = 0;
                var c = a / b;
            return View();
        }

        public IActionResult About()
        {
            HttpContext.RiseError(new InvalidOperationException("Test"));
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
